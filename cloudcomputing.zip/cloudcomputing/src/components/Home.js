import React, { Fragment } from 'react';

export default function Home() {
  return (
    <div className="box cta">
      <p className="has-text-centered">
        <span className="tag is-primary">New</span> UPLOAD A FILE HERE
        </p>
    </div>
  )
}
